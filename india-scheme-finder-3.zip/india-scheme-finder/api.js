/* Runs the data API in the browser so the site works as a single static file.
   Search, duration and automatic removal of expired schemes are computed from today's date on every visit. */
(() => {
const DATA = window.__DATA__, LANGS = window.__LANGS__;
const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const GRACE = 90, SOON = 90;
const today = () => new Date(Date.now() + 5.5 * 3600e3).toISOString().slice(0, 10);
const dn = (s) => Math.round(Date.parse(s + 'T00:00:00Z') / 864e5), between = (a, b) => dn(b) - dn(a);
const fmt = (s) => { const [y, m, d] = s.split('-').map(Number); return `${d} ${MONTHS[m - 1]} ${y}`; };
const span = (n) => { if (n < 1) return 'less than a day'; const y = Math.floor(n / 365), m = Math.floor((n % 365) / 30), d = n - y * 365 - m * 30, p = [];
  if (y) p.push(`${y} year${y > 1 ? 's' : ''}`); if (m) p.push(`${m} month${m > 1 ? 's' : ''}`); if (!y && !m) p.push(`${d} day${d > 1 ? 's' : ''}`); return p.join(' '); };
function evaluate(s, t) {
  const d = s.duration, out = { text: d.text, start: d.start || null, end: d.end || null, cycle: d.cycle || null, reviewBy: d.reviewBy || null, daysLeft: null };
  out.type = d.end ? 'fixed-term' : (d.cycle || /\b(each year|every year|annual|one year at a time|one season|renew)\b/i.test(d.text)) ? 'renewable' : 'ongoing';
  if (d.start && between(t, d.start) > 0) return { ...out, state: 'upcoming', label: `Starts ${fmt(d.start)}` };
  if (!d.end) { const r = d.reviewBy && between(t, d.reviewBy) < 0;
    return { ...out, state: r ? 'needs-review' : 'ongoing', label: r ? 'No fixed end date, but the current phase is due for review' : out.type === 'renewable' ? 'Renews on a cycle' : 'Ongoing, no fixed end date' }; }
  const left = between(t, d.end); out.daysLeft = left;
  if (left >= 0) return { ...out, state: left <= SOON ? 'ending-soon' : 'active', label: `Runs until ${fmt(d.end)} (${left === 0 ? 'Ends today' : span(left) + ' left'})` };
  if ((d.endConfidence || 'official') === 'official' || -left > GRACE) return { ...out, state: 'expired', label: `Ended ${fmt(d.end)}` };
  return { ...out, state: 'needs-review', label: `Planned period ended ${fmt(d.end)}; extension being verified` };
}

/* ---- search helpers: stop words, synonyms, Hindi / Hinglish keywords ---- */
const STOP = new Set('a an the for of to in on and or is are am me my i we you can could get gets scheme schemes yojana yojna with who what which how want need needs apply application about by from at any there people person please show find give tell have has do does new best all ka ki ke ko se me mein hai hain ke liye'.split(' '));
const SYN = {
  old: ['senior', 'elderly', 'pension'], aged: ['senior', 'elderly'], elderly: ['senior'], senior: ['elderly'], retired: ['pension', 'senior'], retirement: ['pension'],
  woman: ['women'], girl: ['girl', 'women'], girls: ['girl', 'women'], lady: ['women'], ladies: ['women'], mother: ['maternity', 'women'], pregnant: ['maternity'], pregnancy: ['maternity'], maternity: ['pregnan'], daughter: ['girl'],
  kisan: ['farmer', 'farm'], kheti: ['farm', 'farmer'], agriculture: ['farm', 'farmer'], farming: ['farm', 'farmer'], crop: ['farm', 'crop'], fasal: ['crop', 'farm'],
  study: ['student', 'scholarship', 'education'], studying: ['student', 'scholarship'], school: ['student', 'education', 'scholarship'], college: ['student', 'scholarship'], education: ['student', 'scholarship'], padhai: ['student', 'education'], chhatravritti: ['scholarship'],
  job: ['employment', 'job', 'work'], jobs: ['employment', 'job'], naukri: ['employment', 'job'], rozgar: ['employment', 'work'], employment: ['job', 'work'], unemployed: ['employment', 'job'], skill: ['skill', 'training'], training: ['skill'],
  house: ['housing', 'house', 'awas'], home: ['housing', 'house'], ghar: ['housing', 'house'], awas: ['housing'], housing: ['house', 'awas'],
  loan: ['loan', 'credit'], credit: ['loan'], udhaar: ['loan'], karz: ['loan'], mudra: ['mudra', 'loan'],
  health: ['health', 'medical', 'hospital'], medical: ['health', 'hospital'], hospital: ['health', 'medical'], ilaj: ['health', 'medical'], treatment: ['health', 'medical'], insurance: ['insurance', 'bima'], bima: ['insurance'],
  disabled: ['disab', 'divyang'], disability: ['disab', 'divyang'], handicapped: ['disab', 'divyang'], divyang: ['disab'], blind: ['disab'],
  business: ['business', 'enterprise', 'entrepreneur'], shop: ['business', 'vendor'], vyapar: ['business'], startup: ['startup', 'entrepreneur', 'business'], vendor: ['vendor', 'street'],
  tribal: ['tribal', 'sc/st'], adivasi: ['tribal'], dalit: ['sc/st'],
  gas: ['lpg', 'cooking'], lpg: ['gas'], ration: ['food', 'ration'], food: ['ration', 'foodgrain'], anaj: ['food', 'ration'], toilet: ['sanitation', 'toilet'], water: ['water', 'jal'], electricity: ['electric', 'solar', 'power'], solar: ['solar'],
  worker: ['wage', 'labour', 'worker'], labour: ['wage', 'labour', 'worker'], labourer: ['wage', 'labour'], mazdoor: ['wage', 'labour', 'worker'], majdoor: ['wage', 'labour', 'worker'], unorganised: ['unorganised', 'worker'],
  money: ['pension', 'income', 'benefit'], savings: ['saving', 'deposit'], bank: ['bank', 'account'], free: ['free']
};
const HI = {
  'पेंशन': 'pension', 'पेन्शन': 'pension', 'किसान': 'farmer', 'खेती': 'farm', 'कृषि': 'farm', 'घर': 'housing', 'मकान': 'housing', 'आवास': 'housing', 'छात्रवृत्ति': 'scholarship', 'वजीफा': 'scholarship', 'छात्र': 'student', 'छात्रा': 'student', 'विद्यार्थी': 'student', 'शिक्षा': 'education', 'पढ़ाई': 'student',
  'महिला': 'women', 'महिलाएं': 'women', 'महिलाओं': 'women', 'औरत': 'women', 'लड़की': 'girl', 'बेटी': 'girl', 'बच्ची': 'girl', 'गर्भवती': 'maternity', 'मातृत्व': 'maternity',
  'नौकरी': 'employment', 'रोजगार': 'employment', 'रोज़गार': 'employment', 'काम': 'work', 'मजदूर': 'worker', 'मज़दूर': 'worker', 'श्रमिक': 'worker', 'कारीगर': 'artisan', 'कौशल': 'skill', 'प्रशिक्षण': 'training',
  'स्वास्थ्य': 'health', 'इलाज': 'health', 'अस्पताल': 'health', 'बीमा': 'insurance', 'बीमारी': 'health',
  'ऋण': 'loan', 'कर्ज': 'loan', 'कर्ज़': 'loan', 'लोन': 'loan', 'व्यापार': 'business', 'दुकान': 'business', 'कारोबार': 'business', 'उद्योग': 'business',
  'विकलांग': 'disability', 'दिव्यांग': 'disability', 'अपंग': 'disability', 'वृद्ध': 'senior', 'बुजुर्ग': 'senior', 'बूढ़े': 'senior', 'सीनियर': 'senior',
  'आदिवासी': 'tribal', 'जनजाति': 'tribal', 'गैस': 'lpg', 'राशन': 'ration', 'अनाज': 'food', 'शौचालय': 'toilet', 'पानी': 'water', 'बिजली': 'electricity', 'सौर': 'solar', 'बैंक': 'bank', 'खाता': 'account', 'योजना': '', 'सरकारी': ''
};
function tokens(raw) {
  const words = String(raw).toLowerCase().replace(/[^\p{L}\p{M}\p{N}\/\s-]/gu, ' ').split(/\s+/).filter(Boolean);
  const out = [];
  for (let w of words) {
    if (HI[w] !== undefined) { if (HI[w]) w = HI[w]; else continue; }
    if (STOP.has(w)) continue;
    const base = w.length > 4 && w.endsWith('s') ? w.slice(0, -1) : w;
    out.push([...new Set([w, base, ...(SYN[w] || []), ...(SYN[base] || [])])]);
  }
  return out;
}
const live = () => { const t = today(); return DATA.map((s) => ({ ...s, duration: evaluate(s, t) })).filter((s) => s.duration.state !== 'expired'); }; // expired = gone
const hay = (s) => { const name = `${s.name} ${s.aliases}`.toLowerCase(), tag = `${s.tagline} ${DATA.cats[s.category]}`.toLowerCase();
  return { name, tag, all: `${name} ${tag} ${s.about} ${s.benefits.join(' ')} ${s.eligibility.join(' ')} ${s.who.map((w) => DATA.who[w]).join(' ')}`.toLowerCase() }; };

/* ---- translation (not bundled) ---- */
const cache = new Map();
class Err extends Error { constructor(m, status) { super(m); this.status = status; } }
async function translate() { throw new Err('Translation is not available', 503); }
async function translateScheme(s, to) {
  const f = [s.name, s.tagline, s.about, s.howToApply, s.duration.text, s.duration.label, s.note || '', ...s.benefits, ...s.eligibility, ...s.documents];
  const t = await translate(f, 'en', to); const [name, tagline, about, howToApply, dt, dl, note] = t; let i = 7;
  const take = (a) => a.map(() => t[i++]);
  return { ...s, name, tagline, about, howToApply, note: s.note ? note : undefined, benefits: take(s.benefits), eligibility: take(s.eligibility), documents: take(s.documents), duration: { ...s.duration, text: dt, label: dl }, lang: to };
}

async function handle(url, init) {
  const u = new URL(url, location.href), p = u.pathname, q = Object.fromEntries(u.searchParams);
  const body = init && init.body ? JSON.parse(init.body) : {};
  try {
    if (p === '/api/meta') { const l = live(), counts = {}; l.forEach((s) => { counts[s.category] = (counts[s.category] || 0) + 1; }); return ok({ categories: DATA.cats, who: DATA.who, counts, total: l.length, today: today() }); }
    if (p === '/api/languages') return ok({ languages: LANGS });
    if (p === '/api/schemes') {
      const toks = tokens(q.q || ''), st = q.state ? q.state.split(',') : null, hits = [];
      for (const s of live()) {
        if (q.category && q.category !== 'all' && s.category !== q.category) continue;
        if (q.who && q.who !== 'all' && !s.who.includes(q.who) && !s.who.includes('all')) continue;
        if (st && !st.includes(s.duration.state)) continue;
        let sc = 1;
        if (toks.length) {
          const h = hay(s); let matched = 0; sc = 0;
          for (const variants of toks) {
            let best = 0;
            for (const v of variants) { if (h.all.includes(v)) best = Math.max(best, 1 + (h.name.includes(v) ? 6 : 0) + (h.tag.includes(v) ? 3 : 0)); }
            if (best) { matched++; sc += best; }
          }
          if (matched < Math.max(1, Math.ceil(toks.length / 2))) continue;
          sc += matched * 10;
        }
        hits.push([s, sc]);
      }
      if (toks.length) hits.sort((a, b) => b[1] - a[1]);
      return ok({ total: hits.length, schemes: hits.map((h) => h[0]) });
    }
    if (p === '/api/expiring') { const days = Number(q.days) || 90; const l = live().filter((s) => s.duration.daysLeft !== null && s.duration.daysLeft <= days).sort((a, b) => a.duration.daysLeft - b.duration.daysLeft); return ok({ days, total: l.length, schemes: l }); }
    let m = /^\/api\/schemes\/([a-z0-9-]+)$/.exec(p);
    if (m) { const s = live().find((x) => x.id === m[1]); if (!s) return ok({ error: 'scheme not found (it may have expired)' }, 404); return ok(q.lang && q.lang !== 'en' ? await translateScheme(s, q.lang) : s); }
    if (p === '/api/translate') {
      if (!body.to) return ok({ error: '"to" is required' }, 400);
      if (Array.isArray(body.texts)) return ok({ to: body.to, translations: await translate(body.texts, body.from || 'auto', body.to) });
      const text = String(body.text || ''); const from = body.from || 'auto';
      if (from === body.to) return ok({ text, to: body.to, translated: false });
      return ok({ text: (await translate([text], from, body.to))[0], to: body.to, translated: true });
    }
    return ok({ error: 'unknown route' }, 404);
  } catch (e) { return ok({ error: e.message || 'error' }, e.status || 500); }
}
const ok = (b, status = 200) => new Response(JSON.stringify(b), { status, headers: { 'content-type': 'application/json' } });
const realFetch = window.fetch.bind(window);
window.fetch = (u, init) => (typeof u === 'string' && u.startsWith('/api/') ? handle(u, init) : realFetch(u, init));

})();
