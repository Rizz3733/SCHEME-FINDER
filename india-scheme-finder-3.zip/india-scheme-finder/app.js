'use strict';
(() => {
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const store = { get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch { return d; } }, set(k, v) { try { localStorage.setItem(k, v); } catch {} } };

// Interface text. Languages without an entry fall back to English; scheme content is translated through the API.
const T = {
  en: { skip: 'Skip to schemes', h1: 'Government schemes you may be eligible for', lead: 'Central-government schemes only, each with who can apply, how long it runs and where to apply. Expired schemes are removed automatically.',
    searchLabel: 'Search schemes', ph: 'Try: pension, farmer, scholarship, housing', tAll: 'All schemes', tNew: 'Ending soon', trH: 'Translator', trP: 'Type or speak, then translate. Useful for reading scheme forms or explaining a scheme to someone.', trGo: 'Translate',
    found: (n) => `${n} scheme${n === 1 ? '' : 's'}`, none: 'No schemes match. Try fewer words or another category.', newNone: 'No schemes are ending soon.',
    active: 'Open', 'ending-soon': 'Ending soon', ongoing: 'Ongoing', 'needs-review': 'Needs review', upcoming: 'Upcoming',
    benefits: 'What you get', eligibility: 'Who can apply', docs: 'Documents needed', how: 'How to apply', dur: 'Duration', portal: 'Open official website', listen: '🔊 Listen', stop: '⏹ Stop',
    review: 'The planned period of this scheme has ended and an extension is being verified. Please confirm on the official website before applying.',
    fallback: 'Translation is unavailable right now, so this is shown in English.', err: 'Could not load schemes. Check your connection.', retry: 'Try again', allCats: 'All', allWho: 'Everyone', shownFor: (q) => `Showing results for “${q}”` },
  hi: { skip: 'योजनाओं पर जाएँ', h1: 'सरकारी योजनाएँ जिनके लिए आप पात्र हो सकते हैं', lead: 'केवल केंद्र सरकार की योजनाएँ: कौन आवेदन कर सकता है, कितने समय चलती है और कहाँ आवेदन करें। समाप्त योजनाएँ अपने आप हट जाती हैं।',
    searchLabel: 'योजना खोजें', ph: 'खोजें: pension, farmer, scholarship', tAll: 'सभी योजनाएँ', tNew: 'जल्द समाप्त', trH: 'अनुवादक', trP: 'लिखें या बोलें, फिर अनुवाद करें।', trGo: 'अनुवाद करें',
    found: (n) => `${n} योजनाएँ`, none: 'कोई योजना नहीं मिली। कम शब्द या दूसरी श्रेणी आज़माएँ।', newNone: 'कोई योजना जल्द समाप्त नहीं हो रही।',
    active: 'खुली', 'ending-soon': 'जल्द समाप्त', ongoing: 'जारी', 'needs-review': 'जाँच ज़रूरी', upcoming: 'आने वाली',
    benefits: 'क्या मिलता है', eligibility: 'कौन आवेदन कर सकता है', docs: 'ज़रूरी दस्तावेज़', how: 'आवेदन कैसे करें', dur: 'अवधि', portal: 'आधिकारिक वेबसाइट खोलें', listen: '🔊 सुनें', stop: '⏹ रोकें',
    review: 'इस योजना की निर्धारित अवधि समाप्त हो चुकी है और विस्तार की पुष्टि हो रही है। आवेदन से पहले आधिकारिक वेबसाइट देखें।',
    fallback: 'अनुवाद अभी उपलब्ध नहीं है, इसलिए अंग्रेज़ी में दिखाया गया है।', err: 'योजनाएँ लोड नहीं हो सकीं।', retry: 'फिर कोशिश करें', allCats: 'सभी', allWho: 'सभी लोग', shownFor: (q) => `“${q}” के नतीजे` },
};
const S = { lang: store.get('lang', 'en'), q: '', cat: 'all', who: 'all', state: '', view: 'all', meta: null, langs: [], list: [], seq: 0, tc: {} };
const t = (k, ...a) => { const v = (T[S.lang] || T.en)[k] ?? T.en[k]; return typeof v === 'function' ? v(...a) : v; };

async function api(path, body) {
  const res = await fetch(path, body ? { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) } : undefined);
  const j = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(j.error || `HTTP ${res.status}`);
  return j;
}
const speechCode = (l) => (S.langs.find((x) => x.code === l) || {}).speech || 'en-IN';
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;

/* ---------- static text ---------- */
function applyText() {
  document.documentElement.lang = S.lang;
  document.querySelectorAll('[data-i]').forEach((e) => { e.textContent = t(e.dataset.i); });
  document.querySelectorAll('[data-i-ph]').forEach((e) => { e.placeholder = t(e.dataset.iPh); });
}

/* ---------- list ---------- */
const ST_ORDER = ['active', 'ending-soon', 'ongoing', 'needs-review', 'upcoming'];
function runway(d, today) {
  if (!d.start || !d.end) return '';
  const a = Date.parse(d.start), b = Date.parse(d.end), n = Date.parse(today);
  const pct = Math.max(0, Math.min(100, Math.round(((n - a) / (b - a)) * 100)));
  return `<div class="runway" role="img" aria-label="${pct}% of the period has passed"><i style="width:${pct}%"></i></div>`;
}
function render(note) {
  const cats = (S.meta || {}).categories || {};
  let list = S.list;
  if (S.view === 'new' && S.cat !== 'all') list = list.filter((s) => s.category === S.cat);
  $('count').textContent = list.length ? `${t('found', list.length)}${note ? ' · ' + t('shownFor', note) : ''}` : '';
  $('empty').hidden = list.length > 0;
  $('empty').textContent = list.length ? '' : (S.view === 'new' ? t('newNone') : t('none'));
  $('list').innerHTML = list.map((s) => `<li class="card"><button type="button" class="open" data-id="${esc(s.id)}">
    <span class="cat">${esc(cats[s.category] || s.category)}</span><h3 data-k="${esc(s.name)}">${esc(s.name)}</h3><p data-k="${esc(s.tagline)}">${esc(s.tagline)}</p>
    <span class="badge s-${esc(s.duration.state)}">${esc(t(s.duration.state))}</span>
    <span class="dur">${esc(s.duration.label)}${runway(s.duration, (S.meta || {}).today)}</span></button></li>`).join('');
  translateCards();
}
async function load() {
  const my = ++S.seq; let q = S.q.trim(), note = '';
  try {
    const data = S.view === 'new' ? await api('/api/expiring?days=180')
      : await api('/api/schemes?' + new URLSearchParams({ q, category: S.cat, who: S.who, state: S.state }));
    if (my !== S.seq) return;
    S.list = data.schemes; render(note);
  } catch (e) {
    if (my !== S.seq) return;
    $('list').innerHTML = ''; $('count').textContent = ''; $('empty').hidden = false;
    $('empty').innerHTML = `${esc(t('err'))} <button type="button" id="retry">${esc(t('retry'))}</button>`;
    $('retry').onclick = load;
  }
}
async function translateCards() {
  if (S.lang === 'en') return;
  const cache = (S.tc[S.lang] = S.tc[S.lang] || {});
  const els = [...document.querySelectorAll('#list [data-k]')];
  const need = [...new Set(els.map((e) => e.dataset.k).filter((k) => !cache[k]))];
  try {
    for (let i = 0; i < need.length; i += 80) {
      const part = need.slice(i, i + 80);
      const r = await api('/api/translate', { texts: part, from: 'en', to: S.lang });
      part.forEach((k, j) => { cache[k] = r.translations[j]; });
    }
  } catch { /* keep English on failure */ }
  els.forEach((e) => { if (cache[e.dataset.k]) e.textContent = cache[e.dataset.k]; });
}

/* ---------- details ---------- */
let speaking = false;
function speak(text, lang, btn, labels) {
  if (!('speechSynthesis' in window)) return;
  if (speaking) { speechSynthesis.cancel(); return; }
  const u = new SpeechSynthesisUtterance(text); u.lang = speechCode(lang);
  u.onstart = () => { speaking = true; btn.textContent = labels[1]; };
  u.onend = u.onerror = () => { speaking = false; btn.textContent = labels[0]; };
  speechSynthesis.speak(u);
}
const ul = (a) => (a && a.length ? `<ul>${a.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>` : '');
async function openScheme(id) {
  const dlg = $('dlg'); $('dbody').innerHTML = '<p class="muted">…</p>'; if (!dlg.open) dlg.showModal();
  let s, fb = false;
  try { s = await api(`/api/schemes/${encodeURIComponent(id)}${S.lang !== 'en' ? '?lang=' + S.lang : ''}`); }
  catch { try { s = await api(`/api/schemes/${encodeURIComponent(id)}`); fb = S.lang !== 'en'; } catch (e) { $('dbody').innerHTML = `<p>${esc(e.message)}</p>`; return; } }
  const lang = fb ? 'en' : S.lang, d = s.duration, cats = (S.meta || {}).categories || {};
  $('dbody').innerHTML = `<p class="cat">${esc(cats[s.category] || '')}</p><h2 id="dh">${esc(s.name)}</h2><p>${esc(s.tagline)}</p>
    
    <div class="box"><span class="badge s-${esc(d.state)}">${esc(t(d.state))}</span><p><strong>${esc(t('dur'))}:</strong> ${esc(d.label)}</p><p>${esc(d.text)}</p>${runway(d, (S.meta || {}).today)}</div>
    ${d.state === 'needs-review' ? `<p class="notice">${esc(t('review'))}</p>` : ''}
    <p>${esc(s.about)}</p>
    <h4>${esc(t('benefits'))}</h4>${ul(s.benefits)}<h4>${esc(t('eligibility'))}</h4>${ul(s.eligibility)}<h4>${esc(t('docs'))}</h4>${ul(s.documents)}
    <h4>${esc(t('how'))}</h4><p>${esc(s.howToApply)}</p>${s.note ? `<p class="muted">${esc(s.note)}</p>` : ''}
    <div class="actions"><a class="primary" href="${esc(s.link)}" target="_blank" rel="noopener noreferrer">${esc(t('portal'))}</a><button type="button" id="dlisten" ${'speechSynthesis' in window ? '' : 'hidden'}>${esc(t('listen'))}</button></div>`;
  const text = [s.name, s.tagline, d.label, t('benefits'), ...s.benefits, t('eligibility'), ...s.eligibility, t('how'), s.howToApply].join('. ');
  $('dlisten').onclick = (e) => speak(text, lang, e.currentTarget, [t('listen'), t('stop')]);
}

/* ---------- voice input ---------- */
let rec = null;
function dictate(btn, lang, onText, onMsg, onInterim) {
  if (rec) { try { rec.stop(); } catch {} return; }
  if (!SR) { onMsg('Voice search is not supported in this browser. Please use Chrome, Edge or Safari.'); return; }
  const r = new SR(); rec = r; let got = false;
  r.lang = speechCode(lang); r.interimResults = true; r.continuous = false; r.maxAlternatives = 1;
  btn.classList.add('on'); btn.setAttribute('aria-pressed', 'true'); onMsg('Listening… speak now');
  r.onresult = (e) => {
    let txt = '', fin = false;
    for (let i = e.resultIndex; i < e.results.length; i++) { txt += e.results[i][0].transcript; if (e.results[i].isFinal) fin = true; }
    if (fin) { got = true; onMsg(''); onText(txt.trim()); } else if (onInterim) onInterim(txt.trim());
  };
  r.onerror = (e) => {
    const m = { 'not-allowed': 'Microphone access was blocked. Tap the lock icon in the address bar and allow the microphone.', 'service-not-allowed': 'Microphone access was blocked. Please allow it in your browser settings.', 'no-speech': 'I did not hear anything. Tap the microphone and try again.', 'audio-capture': 'No microphone was found on this device.', 'network': 'Voice search needs an internet connection.' };
    got = true; onMsg(m[e.error] || 'Could not hear you. Please try again.');
  };
  r.onend = () => { rec = null; btn.classList.remove('on'); btn.setAttribute('aria-pressed', 'false'); if (!got) onMsg(''); };
  try { r.start(); } catch { rec = null; btn.classList.remove('on'); onMsg('Voice input could not start. Please try again.'); }
}

/* ---------- translator ---------- */
async function translateBox() {
  const text = $('src').value.trim(); if (!text) return;
  $('trmsg').textContent = '…'; $('go').disabled = true;
  try { const r = await api('/api/translate', { text, from: $('from').value, to: $('to').value }); $('out').value = r.text; $('trmsg').textContent = r.translated ? '' : 'Same language, nothing to translate.'; }
  catch (e) { $('trmsg').textContent = `Translation failed: ${e.message}`; }
  $('go').disabled = false;
}

/* ---------- setup ---------- */
function fill(sel, opts, val) { sel.innerHTML = opts.map(([v, l]) => `<option value="${esc(v)}">${esc(l)}</option>`).join(''); sel.value = val; }
function buildFilters() {
  const m = S.meta;
  $('chips').innerHTML = [['all', t('allCats'), m.total], ...Object.entries(m.categories).map(([k, n]) => [k, n, m.counts[k] || 0])]
    .map(([k, n, c]) => `<button type="button" class="chip" data-c="${esc(k)}" aria-pressed="${k === S.cat}">${esc(n)}<small>${c}</small></button>`).join('');
  fill($('who'), [['all', t('allWho')], ...Object.entries(m.who).filter(([k]) => k !== 'all')], S.who);
}
async function init() {
  applyText();
  const theme = store.get('theme', ''); if (theme) document.documentElement.dataset.theme = theme;
  $('theme').onclick = () => { const dark = getComputedStyle(document.body).colorScheme === 'dark'; const n = dark ? 'light' : 'dark'; document.documentElement.dataset.theme = n; store.set('theme', n); };
  try { [S.meta, S.langs] = await Promise.all([api('/api/meta'), api('/api/languages').then((r) => r.languages)]); }
  catch { $('empty').hidden = false; $('empty').textContent = t('err'); return; }
  if (!S.langs.some((l) => l.code === S.lang)) S.lang = 'en';
  const lopts = S.langs.map((l) => [l.code, l.native]);
  fill($('lang'), lopts, S.lang); fill($('from'), [['auto', 'Auto-detect'], ...lopts], 'auto'); fill($('to'), lopts, S.lang === 'en' ? 'hi' : S.lang);
  buildFilters(); applyText();
  { const n=Object.keys(S.meta.categories).length; $('st1').textContent=S.meta.total; $('st2').textContent=n; }

  let timer; $('q').addEventListener('input', (e) => { S.q = e.target.value; clearTimeout(timer); timer = setTimeout(load, 250); });
  $('sform').addEventListener('submit', (e) => { e.preventDefault(); clearTimeout(timer); load(); });
  $('who').onchange = (e) => { S.who = e.target.value; load(); };
  $('state').onchange = (e) => { S.state = e.target.value; load(); };
  $('chips').onclick = (e) => { const b = e.target.closest('.chip'); if (!b) return; S.cat = b.dataset.c; document.querySelectorAll('.chip').forEach((c) => c.setAttribute('aria-pressed', c === b)); load(); };
  document.querySelector('.tabs').onclick = (e) => { const b = e.target.closest('[role=tab]'); if (!b) return; S.view = b.dataset.v; document.querySelectorAll('[role=tab]').forEach((x) => x.setAttribute('aria-selected', x === b)); load(); };
  $('list').onclick = (e) => { const b = e.target.closest('.open'); if (b) openScheme(b.dataset.id); };
  $('dclose').onclick = () => $('dlg').close();
  $('dlg').addEventListener('click', (e) => { if (e.target === $('dlg')) $('dlg').close(); });
  $('dlg').addEventListener('close', () => { if ('speechSynthesis' in window) speechSynthesis.cancel(); speaking = false; });
  $('lang').onchange = (e) => { S.lang = e.target.value; $('vlang').value = S.lang === 'hi' ? 'hi' : 'en'; store.set('lang', S.lang); $('to').value = S.lang === 'en' ? $('to').value : S.lang; applyText(); buildFilters(); render(); };

  $('mic').hidden = false; $('vlang').hidden = false; $('vlang').value = S.lang === 'hi' ? 'hi' : 'en';
  const vmsg = (m) => { $('vmsg').textContent = m; };
  $('mic').onclick = (e) => dictate(e.currentTarget, $('vlang').value, (txt) => { $('q').value = S.q = txt; load(); }, vmsg, (txt) => { $('q').value = txt; });
  if (SR) { $('smic').hidden = false; $('smic').onclick = (e) => dictate(e.currentTarget, $('from').value === 'auto' ? S.lang : $('from').value, (txt) => { $('src').value = txt; translateBox(); }, (m) => { $('trmsg').textContent = m; }); }
  if ('speechSynthesis' in window) {
    $('say').hidden = false;
    $('say').onclick = (e) => { const x = $('out').value; if (x) speak(x, $('to').value, e.currentTarget, ['🔊 Listen', '⏹ Stop']); };
  }
  $('go').onclick = translateBox;
  $('swap').onclick = () => { const f = $('from').value === 'auto' ? S.lang : $('from').value, to = $('to').value; $('from').value = to; $('to').value = f; const s = $('src').value; $('src').value = $('out').value; $('out').value = s; };
  $('copy').onclick = async () => { try { await navigator.clipboard.writeText($('out').value); $('trmsg').textContent = 'Copied.'; } catch { $('out').select(); } };
  load();
}
init();
$('yr').textContent = new Date().getFullYear();
})();
