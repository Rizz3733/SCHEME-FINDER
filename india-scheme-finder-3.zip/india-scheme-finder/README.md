# India Scheme Finder

A free, fast website to find central-government schemes of India: who can apply, how long each scheme runs, documents needed, and how to apply.

## Features
- Search by keyword, in plain sentences, Hindi or Hinglish (for example "pension for old people", "किसान", "naukri")
- Voice search in English and Hindi (Chrome, Edge, Safari; needs HTTPS)
- Filter by category, by who the scheme is for, and by status
- "Ending soon" view; expired schemes are removed automatically using today's date
- Works on phones, tablets and desktops, with light and dark mode
- No server and no database to run: it is a static website

## Project structure
| File | Purpose |
|---|---|
| `index.html` | Page structure |
| `style.css` | Design, responsive layout, dark mode |
| `app.js` | Interface logic: cards, filters, scheme popup, voice input |
| `api.js` | Search, filtering and expiry logic (runs in the browser) |
| `data.js` | The scheme data (JSON) |
| `docs/schemes-reference.pdf` | Reference document with additional scheme details |

## Run locally
Open `index.html` in a browser. Or, for voice search, serve it locally:

```bash
python3 -m http.server 8000
# then open http://localhost:8000
```

## Add or edit a scheme
Open `data.js` and copy an existing entry. Fields: `id`, `name`, `aliases` (extra search words), `category`, `who`, `tagline`, `about`, `benefits`, `eligibility`, `documents`, `duration`, `howToApply`, `link`.

To make a scheme expire automatically, set `duration.end` to a date like `"2027-03-31"`.

## Deploy
**GitHub Pages:** Settings > Pages > Deploy from a branch > `main` / root.
**Netlify:** drag the project folder onto app.netlify.com/drop.

## Disclaimer
This is an independent information service and is not affiliated with the Government of India. Information is for guidance only. Always confirm eligibility, dates and amounts on the official portal linked from each scheme.
